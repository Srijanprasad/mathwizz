x2.b
